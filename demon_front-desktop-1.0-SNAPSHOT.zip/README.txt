
Demon Front

Double-click on demon_front.jar to start the game.

If it doesn't work, you may need to install Java: http://java.com/en/download/index.jsp

